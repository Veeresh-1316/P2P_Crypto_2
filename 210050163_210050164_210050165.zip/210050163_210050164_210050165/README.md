## Team Members
- Vinu Rakav S    : 210050165 
- Venkatesh K S   : 210050164 
- Veeresh B Patil : 210050163

## To Run 
Install graphviz and networkx before running the main.py 
>>> pip install graphviz networkx 
You also need to install graphviz backend for drawing the blockchain to .png : 
>>> sudo apt install graphviz (Linux)

>>> python3 main.py [z0] [z1]
Eg : python3 main.py 0.4 0.7

You can use python3 main.py --help (To view the arguments)

## Results 
You can keyboard interrupt the script after some time.
After interrupt, 
You will get result of logs and blockchain png in respective folders (fig & peers)
